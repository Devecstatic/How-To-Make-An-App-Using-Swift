
/// Episode 1: Variables and If-Then Statements
var Username : String? // A variable named Username is of-type string and is nil

if let name = Username {
    print(name) // Print unwrapped username
}


let Password = "p"
/// ---

/// Episode 2: Functions

func createEmail(_ address: String, domain: String) {
    
    print(address + domain)
    
}

createEmail("developerecstatic", domain: "@gmail.com")
/// ---
